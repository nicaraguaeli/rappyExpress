@extends('layout.layout')
@section('contenido')
@include('partial.nav')
@endsection
