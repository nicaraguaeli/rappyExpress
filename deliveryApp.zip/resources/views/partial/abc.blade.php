
<ul class="list-group border-top animated fadeIn" id="myList" style="height: 70vh; overflow: scroll;">
    

    @foreach($categorias as $categoria)
    <li class="list-group-item product  grey lighten-2 " id="{{$categoria->id}}">
     <div class="row">
     <div class="col"> <img src="{{$categoria->imagen}}"  alt="" class="mr-2"></div>
     <div class="col"> <b>{{$categoria->nombre}}</b> </div>
     
    
     <div class="col"> 
      
     <span class="badge green badge-pill ml-2 p-2">
     @php
     $count = 0;
     @endphp
     @foreach($marcas as $marca)
     @if($categoria->id == $marca->categoria)
     
     @php
     $count++;
     @endphp
     @endif
    @endforeach
      {{$count}} marcas</span>
     
     </div>
     <div class="col"> <i class="fas fa-arrow-alt-circle-right grey-text " style="font-size: 1.5rem;"></i></div>
    
   
     </div>
    
    </li>

    @endforeach
    
    
  </ul>  







                 
                  

               