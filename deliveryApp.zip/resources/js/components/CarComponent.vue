<template>
   
        <tr >
        <td ><img src=""></td>
        <td>{{article.nombre | uppercase}} | {{article.marca | uppercase}} | {{article.presentacion | uppercase}}</td>
        <td>C$ {{article.precio | formato}}</td>
        <td><span ><button type="button" class="btn btn-danger btn-rounded btn-sm my-0 waves-effect waves-light" v-on:click="deleteRow()">Quitar</button></span></td>
        </tr>
    
</template>
<script>
export default { 
    
    props:
    {
        article: {},
        
    },
    filters: {
  formato: function (value) {
     
     
     return value.toFixed(2);
  },
  uppercase: function (value) {
     
     
     return value.toUpperCase();
  },

},
methods:
{
  deleteRow()
  {
    this.$emit('delete')
  }
}
    
}
</script>