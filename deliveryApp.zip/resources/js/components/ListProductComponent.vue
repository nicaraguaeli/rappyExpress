<template>
    
    <div >
        <ul class="list-group border-top " id="myList" style="height: 70vh; overflow: scroll;">
    

   
    <li v-for="item in info" :key="item.id" class="list-group-item product  grey lighten-2 " v-on:click="enviarid(item.id)"   >
     <div class="row">
     <div class="col"> <img :src="item.imagen"  alt="" class="mr-2"></div>
     <div class="col"> <b>{{item.nombre}}</b> </div>
     
    
     <div class="col"> 
      
     <span class="badge green badge-pill ml-2 p-2">
     
       marcas</span>
     
     </div>
     <div class="col">  <i class="fas fa-arrow-alt-circle-right grey-text " style="font-size: 1.5rem;"></i></div>
    
   
     </div>
    
    </li>

   
   
    
  </ul>  
  
    
    </div>
    
  
 
</template>
<script>
export default {
    data () {
    return {
      info: null,
      
      
      
    }
  },
  
    mounted () {
    axios
      .get('./prueba')
      .then(response => (this.info = response.data))
  },
  methods:
  {
    enviarid(value)
    {
        this.$emit('recibirid',value,'false')
        ;
    },
   
  }
  
}
</script>