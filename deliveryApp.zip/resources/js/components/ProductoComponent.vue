<template>
    <div>
       
         <nav aria-label="breadcrumb animated fadeIn ">
  <ol class="breadcrumb m-0">
    <li class="breadcrumb-item inicio"><a  ><i class="fas fa-chevron-left mr-2"></i>
    <b>Atras</b>
    </a></li>
    <li class="breadcrumb-item active uppercase"></li>
  </ol>
</nav>



<div class="container p-0">

<div class="row animated fadeIn m-0" style="height: 70vh; overflow: scroll; ">



<!-- Grid column -->
<div class="col-sm-3" v-for="item in productos" :key="item.id">

  <!-- Card -->
  <div class="card card-ecommerce">

    <!-- Card image -->
    <div class="view overlay">

      <img :src="item.imagen" class="img-fluid" alt="sample image">

      <a>

        <div class="mask rgba-white-slight waves-effect waves-light"></div>

      </a>

    </div>
    <!-- Card image -->

    <!-- Card content -->
    <div class="card-body">

      <!-- Category & Title -->
      <h5 class="card-title mb-1" >

        {{item.nombre}} | {{item.marca}} <strong> 

          <h3 class="dark-grey-text "> </h3>

        </strong>

      </h5>

      <span class="badge badge-danger mb-2 ">{{item.presentacion}}</span>

      
      <!-- Card footer -->
      <div class="card-footer pb-0">

        <div class="row mb-0">

          <span class="float-left ">

            <strong>C$ {{item.precio | formato}} </strong>

          </span>

          <span class="float-right">

            <a  class="add"  v-on:click="enviarpadre(item)">

              <i class="fas fa-shopping-cart ml-3 mr-2" ></i>Agregar

</a>

          </span>

        </div>

      </div>

    </div>
    <!-- Card content -->

  </div>
  <!-- Card -->

</div>
<!-- Grid column -->






</div>

</div>

    </div>
</template>

<script>
export default {
  
  
  props: 
  {
    productos: {},
    
  },
   
  methods:{
      
      enviarpadre(item)
      {
          this.$emit('escucharhijo',item)
          
      },
      
     
  },
  filters: {
  formato: function (value) {
    
    return value.toFixed(2);
  }
}
  
}
</script>