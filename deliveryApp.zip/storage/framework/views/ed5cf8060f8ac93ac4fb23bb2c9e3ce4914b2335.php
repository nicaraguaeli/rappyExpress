<nav aria-label="breadcrumb animated fadeIn ">
  <ol class="breadcrumb m-0">
    <li class="breadcrumb-item inicio"><a class="inicio" ><i class="fas fa-chevron-left mr-2"></i>
    <b>Atras</b>
    </a></li>
    <li class="breadcrumb-item active uppercase"><?php echo e($param->nombre); ?></li>
  </ol>
</nav>



<div class="container p-0">

<div class="row animated fadeIn" style="height: 70vh; overflow: scroll; ">


<?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Grid column -->
<div class="col-md-6">

  <!-- Card -->
  <div class="card card-ecommerce">

    <!-- Card image -->
    <div class="view overlay">

      <img src="<?php echo e(asset('img/arrozfaisan.jpg')); ?>" class="img-fluid" alt="sample image">

      <a>

        <div class="mask rgba-white-slight waves-effect waves-light"></div>

      </a>

    </div>
    <!-- Card image -->

    <!-- Card content -->
    <div class="card-body">

      <!-- Category & Title -->
      <h5 class="card-title mb-1">

        <strong>

          <h3 class="dark-grey-text "><?php echo e($dato->nombre); ?> | <?php echo e($dato->marca); ?> </h3>

        </strong>

      </h5>

      <span class="badge badge-danger mb-2 "><?php echo e($dato->presentacion); ?></span>

      
      <!-- Card footer -->
      <div class="card-footer pb-0">

        <div class="row mb-0">

          <span class="float-left ">

            <strong>C$ <?php echo e(number_format($dato->precio, 2)); ?></strong>

          </span>

          <span class="float-right">

            <a  class="add" id="<?php echo e($dato->id); ?>">

              <i class="fas fa-shopping-cart ml-3 mr-2" ></i>Agregar

</a>

          </span>

        </div>

      </div>

    </div>
    <!-- Card content -->

  </div>
  <!-- Card -->

</div>
<!-- Grid column -->

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





</div>

</div><?php /**PATH C:\xampp\htdocs\deliveryApp\resources\views/partial/products.blade.php ENDPATH**/ ?>