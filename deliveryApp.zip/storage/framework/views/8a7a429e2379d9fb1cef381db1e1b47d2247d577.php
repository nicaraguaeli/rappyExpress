
<ul class="list-group border-top animated fadeIn" id="myList" style="height: 70vh; overflow: scroll;">
    

    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="list-group-item product  grey lighten-2 " id="<?php echo e($categoria->id); ?>">
     <div class="row">
     <div class="col"> <img src="<?php echo e($categoria->imagen); ?>"  alt="" class="mr-2"></div>
     <div class="col"> <b><?php echo e($categoria->nombre); ?></b> </div>
     
    
     <div class="col"> 
      
     <span class="badge green badge-pill ml-2 p-2">
     <?php
     $count = 0;
     ?>
     <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <?php if($categoria->id == $marca->categoria): ?>
     
     <?php
     $count++;
     ?>
     <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php echo e($count); ?> marcas</span>
     
     </div>
     <div class="col"> <i class="fas fa-arrow-alt-circle-right grey-text " style="font-size: 1.5rem;"></i></div>
    
   
     </div>
    
    </li>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    
  </ul>  







                 
                  

               <?php /**PATH C:\xampp\htdocs\deliveryApp\resources\views/partial/abc.blade.php ENDPATH**/ ?>